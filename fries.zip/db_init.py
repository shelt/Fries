import sqlite3

con = sqlite3.connect("main.db")
con.isolation_level = None
c = con.cursor()

c.execute("CREATE TABLE Users (id int, name text, mail text, hash text, salt text, lkarma int, ckarma text)")

con.close()