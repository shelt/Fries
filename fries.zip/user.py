import sqlite3

# Local imports
from crypto import *

con = sqlite3.connect("main.db")
con.isolation_level = None
c = con.cursor()

#NOTE: SQL '?' tuples must use '_t' as var name
#NOTE: the tuples that fetch(one|all)() returns should be called 'res'


#######################
#     USER CLASS      #
#######################
# IDs and names are stored as fields because they
# are used to query the database. Everything else
# is queried itself.

class User:
    def __init__(self, id):
        self.id = id
    
    def inc_lkarma(self):
        _t = (self.id,self.id)
        c.execute("UPDATE Users SET lkarma = ( ( SELECT lkarma FROM Users WHERE id = ? ) + 1 ) WHERE id = ?", _t)
    def inc_ckarma(self):
        _t = (self.id,self.id)
        c.execute("UPDATE Users SET ckarma = ( ( SELECT ckarma FROM Users WHERE id = ? ) + 1 ) WHERE id = ?", _t)

    def dec_lkarma(self):
        _t = (self.id,self.id)
        c.execute("UPDATE Users SET lkarma = ( ( SELECT lkarma FROM Users WHERE id = ? ) - 1 ) WHERE id = ?", _t)
    def dec_ckarma(self):
        _t = (self.id,self.id)
        c.execute("UPDATE Users SET ckarma = ( ( SELECT ckarma FROM Users WHERE id = ? ) - 1 ) WHERE id = ?", _t)

    def get_lkarma(self):
        _t = (self.id,)
        c.execute("SELECT lkarma FROM Users WHERE id = ?", _t)
        res = c.fetchone()
        return res[0]
    def get_ckarma(self):
        _t = (self.id,)
        c.execute("SELECT ckarma FROM Users WHERE id = ?", _t)
        res = c.fetchone()
        return res[0]
        
        


#######################
# USERACCOUNT ACTIONS #
#######################
# Functions related to user auth and
# other account-related activities.

def new_user(username, password, email):
    if user_exists(username):
        return False
    id = get_new_id()
    salt = get_salt()
    hash = get_hash(password, salt)
    _t = (id, username, email, hash, salt, 0, 0)
    c.execute("INSERT INTO Users (id, name, mail, hash, salt, lkarma, ckarma) VALUES(?,?,?,?,?,?,?)", _t)
    return True

def verify_user(username, password):
    _t = (username,)
    c.execute("SELECT * FROM Users WHERE name IS ?", _t)
    res = c.fetchone()
    assert res[1] == username
    if get_hash(password, res[4]) == res[3]:
        return True
    else:
        return False

def user_exists(username):
    _t = (username,)
    c.execute("SELECT count(1) FROM Users WHERE name IS ?", _t)
    if c.fetchone()[0] == 1:
        return True


######################
#    USER GETTERS    #
######################
# These functions get Users.
# Getting user-specific data is done objectively.

# BULK GETTERS

def get_users():
    users = []
    c.execute("SELECT id FROM Users")
    for res in c.fetchall():
        user = User(res[0])
        users.append(user)
    return users
    
def get_users_by_mail(mail):
    users = []
    _t = (mail,)
    c.execute("SELECT id FROM Users WHERE mail IS ?", _t)
    for res in c.fetchall():
        user = User(res[0])
        users.append(user)
    return users

# SINGLE GETTERS

def get_user(id):
    return User(id)

def get_user_by_name(name):
    _t = (name,)
    c.execute("SELECT id FROM Users WHERE name IS ?", _t)
    res = c.fetchone()
    return User(res[0])




#######################
#        MISC         #
#######################

def get_new_id():
    c.execute("SELECT id FROM Users WHERE id = ( SELECT MAX(id) FROM Users )")
    res = c.fetchone()
    if not res: # No users
        return 0
    else:
        return int(res[0])+1



# Testing
new_user('doc', 'root', 'sam@mail.com')
new_user('doc2', 'root', 'sam@mail.com')
new_user('wang', 'moot', 'wang@mail.com')

for i in range(0,10000):
    new_user(str(i), str(i), str(i))
    print "user " + str(i) + " added"
    get_user(i).inc_lkarma()
    print "user " + str(i) + " incremented"
    

con.close()