import hashlib
import uuid

def get_salt():
    return uuid.uuid4().hex

def get_hash(password, salt):
    return hashlib.sha512(password + salt).hexdigest()